testBlock <-function(cells, strata){
  
  
  
}