
# Please build your own test file from test-Template.R, and place it in tests folder
# please specify the package you need to run the sim function in the test files.

# to test all the test files in the tests folder:
test_dir("/home/tmichele/Documents/GitHub/scfmModules/modules/scfmHarvest/tests/testthat")

# Alternative, you can use test_file to test individual test file, e.g.:
test_file("/home/tmichele/Documents/GitHub/scfmModules/modules/scfmHarvest/tests/testthat/test-template.R")
