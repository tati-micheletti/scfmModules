testBlock <-function(cells, strata){
  
  
  return(invisible(sim))
}