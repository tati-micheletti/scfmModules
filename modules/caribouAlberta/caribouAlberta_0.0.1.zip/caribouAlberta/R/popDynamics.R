# popDynamics <- function(stat = sim$SorensenStats){
#   
#   browser()
#   
#   graph <- NA 
#     
#   return(graph)
# }