hatP0<-function(pE,n=8){
  1 - (1-pE)**(1/n)
}